2,000 Pixel-Art Sprites Pack (sampler)
MoonBite Partners

24 game-ready sprites + sprite sheet. 32x32 source, PNG with alpha.
License: use in commercial and personal games. No resale of the pack itself.
