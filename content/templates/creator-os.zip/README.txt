Creator OS � Notion template export
Import the CSVs into Notion databases; see the setup guide (PDF).
