Ambient Focus � sampler (2 of N tracks). FLAC available in the full album.
