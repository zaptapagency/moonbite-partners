Lo-Fi UI Kit
MoonBite Partners

Preview sheet + handbook (PDF).
Full Figma file link inside the handbook. 120+ components, both themes.
